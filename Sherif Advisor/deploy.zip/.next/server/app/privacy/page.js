(()=>{var e={};e.id=385,e.ids=[385],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},63036:(e,r,i)=>{"use strict";i.r(r),i.d(r,{GlobalError:()=>o.Z,__next_app__:()=>c,originalPathname:()=>u,pages:()=>p,routeModule:()=>d,tree:()=>l}),i(46146),i(55312),i(49356),i(59198);var t=i(30170),s=i(45002),o=i(54512),a=i(66299),n={};for(let e in a)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>a[e]);i.d(r,n);let l=["",{children:["privacy",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(i.bind(i,46146)),"D:\\Sheriv_repo\\Sherif-Yousry\\Sherif Advisor\\website\\src\\app\\privacy\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(i.bind(i,55312)),"D:\\Sheriv_repo\\Sherif-Yousry\\Sherif Advisor\\website\\src\\app\\layout.tsx"],error:[()=>Promise.resolve().then(i.bind(i,49356)),"D:\\Sheriv_repo\\Sherif-Yousry\\Sherif Advisor\\website\\src\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(i.bind(i,59198)),"D:\\Sheriv_repo\\Sherif-Yousry\\Sherif Advisor\\website\\src\\app\\not-found.tsx"]}],p=["D:\\Sheriv_repo\\Sherif-Yousry\\Sherif Advisor\\website\\src\\app\\privacy\\page.tsx"],u="/privacy/page",c={require:i,loadChunk:()=>Promise.resolve()},d=new t.AppPageRouteModule({definition:{kind:s.x.APP_PAGE,page:"/privacy/page",pathname:"/privacy",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:l}})},68304:(e,r,i)=>{Promise.resolve().then(i.bind(i,50633))},50633:(e,r,i)=>{"use strict";i.r(r),i.d(r,{default:()=>p});var t=i(97247),s=i(28964),o=i(25986),a=i(42447),n=i(42557);let l=()=>"ar";function p(){let[e,r]=(0,s.useState)(l),[i,p]=(0,s.useState)(!1),[u,c]=(0,s.useState)(null),[d,h]=(0,s.useState)(!0),m="ar"===e?`<p>مرحباً بكم في <strong>شريف يسري للاستشارات</strong>. نحن نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية وفقاً لأعلى المعايير المهنية والقوانين المعمول بها في مصر ومنطقة الشرق الأوسط.</p>

<h2>1. المعلومات التي نجمعها</h2>
<p>نقوم بجمع المعلومات التي تقدمها لنا طواعية عند:</p>
<ul>
<li>التواصل معنا عبر نماذج الموقع الإلكتروني أو البريد الإلكتروني.</li>
<li>طلب خدمات استشارية أو حجز جلسة تقييم.</li>
<li>الاشتراك في نشراتنا الإخبارية أو الرؤى المهنية.</li>
</ul>
<p>تشمل هذه المعلومات: الاسم، عنوان البريد الإلكتروني، رقم الهاتف، اسم الشركة، وتفاصيل متعلقة بطبيعة الاستفسار.</p>

<h2>2. كيفية استخدام معلوماتك</h2>
<p>نستخدم البيانات التي نجمعها للأغراض التالية فقط:</p>
<ul>
<li>تقديم خدماتنا الاستشارية والمالية والضريبية بكفاءة.</li>
<li>الرد على استفساراتك وطلباتك في الوقت المناسب.</li>
<li>تحسين تجربة المستخدم على موقعنا الإلكتروني ومحتوياته.</li>
<li>إرسال تحديثات مهنية أو تنظيمية (فقط إذا وافقت صراحة على ذلك).</li>
</ul>

<h2>3. حماية وأمن البيانات</h2>
<p>نطبق إجراءات أمنية تقنية وإدارية متقدمة لحماية بياناتك من الوصول غير المصرح به، أو التعديل، أو الإفصاح، أو الإتلاف. نحن لا نبيع أو نؤجر أو نشارك معلوماتك الشخصية مع أطراف ثالثة لأغراض تسويقية.</p>

<h2>4. ملفات تعريف الارتباط (Cookies)</h2>
<p>يستخدم موقعنا ملفات تعريف الارتباط لتحسين تجربتك وتحليل حركة المرور. يمكنك ضبط متصفحك لرفض ملفات تعريف الارتباط، ولكن قد يؤثر ذلك على بعض وظائف الموقع.</p>

<h2>5. حقوقك</h2>
<p>يحق لك في أي وقت طلب الوصول إلى بياناتك الشخصية، أو تصحيحها، أو حذفها، أو سحب موافقتك على معالجتها. يمكنك ممارسة هذه الحقوق عن طريق التواصل معنا.</p>

<h2>6. تواصل معنا</h2>
<p>إذا كان لديك أي أسئلة أو مخاوف بشأن سياسة الخصوصية هذه أو كيفية تعاملنا مع بياناتك، يرجى التواصل معنا عبر:</p>
<ul>
<li>البريد الإلكتروني: <a href="mailto:info@sherifyousry.com">info@sherifyousry.com</a></li>
<li>العنوان: القاهرة، مصر</li>
</ul>
<p><em>آخر تحديث: سبتمبر 2026</em></p>`:`<p>Welcome to <strong>Sherif Yousry Advisory</strong>. We respect your privacy and are committed to protecting your personal data in accordance with the highest professional standards and applicable laws in Egypt and the Middle East region.</p>

<h2>1. Information We Collect</h2>
<p>We collect information that you voluntarily provide to us when you:</p>
<ul>
<li>Contact us via website forms or email.</li>
<li>Request advisory services or book an assessment session.</li>
<li>Subscribe to our newsletters or professional insights.</li>
</ul>
<p>This information includes: name, email address, phone number, company name, and details related to the nature of your inquiry.</p>

<h2>2. How We Use Your Information</h2>
<p>We use the data we collect solely for the following purposes:</p>
<ul>
<li>To deliver our financial, tax, and business advisory services efficiently.</li>
<li>To respond to your inquiries and requests in a timely manner.</li>
<li>To improve the user experience and content of our website.</li>
<li>To send professional or regulatory updates (only if you have explicitly consented).</li>
</ul>

<h2>3. Data Protection and Security</h2>
<p>We implement advanced technical and administrative security measures to protect your data from unauthorized access, alteration, disclosure, or destruction. We do not sell, rent, or share your personal information with third parties for marketing purposes.</p>

<h2>4. Cookies</h2>
<p>Our website uses cookies to enhance your experience and analyze traffic. You can configure your browser to refuse cookies, but this may affect the functionality of certain parts of the site.</p>

<h2>5. Your Rights</h2>
<p>You have the right at any time to request access to, correction of, or deletion of your personal data, or to withdraw your consent to its processing. You can exercise these rights by contacting us.</p>

<h2>6. Contact Us</h2>
<p>If you have any questions or concerns about this Privacy Policy or how we handle your data, please contact us at:</p>
<ul>
<li>Email: <a href="mailto:info@sherifyousry.com">info@sherifyousry.com</a></li>
<li>Address: Cairo, Egypt</li>
</ul>
<p><em>Last Updated: September 2026</em></p>`,y=u?.title||("ar"===e?"سياسة الخصوصية":"Privacy Policy"),x=u?.body||m;return(0,t.jsxs)("main",{dir:(0,n.Mg)(e),className:"min-h-screen flex flex-col",children:[t.jsx(o.Header,{}),t.jsx("section",{className:"bg-brand-navy py-16 lg:py-20",children:t.jsx("div",{className:"max-w-3xl mx-auto px-6 lg:px-8",children:d?t.jsx("div",{className:"h-10 w-64 bg-white/10 animate-pulse rounded"}):t.jsx("h1",{className:"font-amiri text-3xl md:text-4xl text-text-primary leading-relaxed",children:y})})}),t.jsx("section",{className:"bg-surface-light py-16 flex-grow",children:t.jsx("div",{className:"max-w-3xl mx-auto px-6 lg:px-8",children:d?(0,t.jsxs)("div",{className:"space-y-4",children:[t.jsx("div",{className:"h-4 w-full bg-gray-200 animate-pulse rounded"}),t.jsx("div",{className:"h-4 w-5/6 bg-gray-200 animate-pulse rounded"}),t.jsx("div",{className:"h-4 w-4/6 bg-gray-200 animate-pulse rounded"})]}):t.jsx("div",{className:"text-text-dark-secondary leading-8 space-y-6   [&_h2]:text-2xl [&_h2]:font-amiri [&_h2]:text-text-primary [&_h2]:mt-8 [&_h2]:mb-4   [&_h3]:text-xl [&_h3]:font-semibold [&_h3]:text-text-primary [&_h3]:mt-6 [&_h3]:mb-3   [&_p]:mb-4 [&_p]:leading-8   [&_ul]:list-disc [&_ul]:ps-6 [&_ul]:mb-4 [&_li]:mb-2   [&_a]:text-brand-gold [&_a]:underline hover:[&_a]:text-brand-gold/80",dangerouslySetInnerHTML:{__html:x}})})}),t.jsx(a.Footer,{})]})}},46146:(e,r,i)=>{"use strict";i.r(r),i.d(r,{default:()=>t});let t=(0,i(45347).createProxy)(String.raw`D:\Sheriv_repo\Sherif-Yousry\Sherif Advisor\website\src\app\privacy\page.tsx#default`)}};var r=require("../../webpack-runtime.js");r.C(e);var i=e=>r(r.s=e),t=r.X(0,[7285,3051,2931,2459,2447,5986],()=>i(63036));module.exports=t})();