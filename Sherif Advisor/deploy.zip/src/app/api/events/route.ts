// Force dynamic rendering - reads request data / queries the DB at runtime
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
// ⚠️ Adjust this import path to match where you saved the Public Content Delivery Module
import { getPublishedEvents } from '@/lib/public-content'; 

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Extract query parameters
    const lang = (searchParams.get('lang') as 'ar' | 'en') || 'en';
    const page = parseInt(searchParams.get('page') || '1', 10);
    const pageSize = parseInt(searchParams.get('pageSize') || '50', 10);
    const category = searchParams.get('category') || undefined;
    const eventType = searchParams.get('eventType') || undefined;

    const result = await getPublishedEvents(lang, page, category, pageSize, eventType);

    return NextResponse.json(result, {
      headers: {
        'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=60',
      },
    });
  } catch (error) {
    console.error('Error fetching events:', error);
    return NextResponse.json(
      { error: 'Failed to fetch events' }, 
      { status: 500 }
    );
  }
}